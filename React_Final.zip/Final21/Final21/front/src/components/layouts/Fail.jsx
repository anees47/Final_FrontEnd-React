import React, { Component } from 'react'
import "../../App.css";


export default class Fail extends Component {
    render() {
        return (
            <div className="landing1">
                Fail!!
            </div>
        )
    }
}
