import React, { Component } from 'react';
import "../../App.css";

export default class Success extends Component {
    render() {
        return (
            <div className="landing1">
                <center> Success!!! </center>
             </div>
        )
    }
}

